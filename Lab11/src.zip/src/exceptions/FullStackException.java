package exceptions;

public class FullStackException extends RuntimeException {

	public FullStackException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FullStackException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FullStackException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FullStackException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
