package exceptions;

public class EmptyStackException extends RuntimeException {

	public EmptyStackException() {
		// TODO Auto-generated constructor stub
	}

	public EmptyStackException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmptyStackException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmptyStackException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
