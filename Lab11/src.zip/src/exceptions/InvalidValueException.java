package exceptions;

public class InvalidValueException extends RuntimeException {

	public InvalidValueException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidValueException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
